
from typing import List, Optional, Union
from lexer import tokenize, Token
from ast_nodes import *

class Parser:
    def __init__(self, src: str):
        self.tokens: List[Token] = tokenize(src)
        self.i = 0
        self.src = src

    def peek(self) -> Token:
        return self.tokens[self.i]

    def pop(self, expected_kind=None, expected_value=None) -> Token:
        tok = self.peek()
        if expected_kind and tok.kind != expected_kind:
            raise SyntaxError(f"Expected {expected_kind} at {tok.line}:{tok.col}, got {tok.kind}")
        if expected_value and tok.value != expected_value:
            raise SyntaxError(f"Expected {expected_value} at {tok.line}:{tok.col}, got {tok.value}")
        self.i += 1
        return tok

    def match(self, kind, value=None) -> bool:
        tok = self.peek()
        if tok.kind != kind:
            return False
        if value is not None and tok.value != value:
            return False
        self.i += 1
        return True

    # === Program ===
    def parse_program(self) -> Program:
        funcs: List[FuncDef] = []
        while self.peek().kind != "EOF":
            funcs.append(self.parse_func())
        return Program(funcs=funcs)

    # === Types ===
    def parse_type(self) -> TypeSpec:
        tok = self.peek()
        if tok.kind == "KW" and tok.value in ("int","char","bool","void"):
            self.pop()
            return TypeSpec(tok.value)
        raise SyntaxError(f"Type expected at {tok.line}:{tok.col}")

    # === Function ===
    def parse_func(self) -> FuncDef:
        rtype = self.parse_type()
        name = self.pop("IDENT").value
        self.pop("PUNC","(")
        params: List[Param] = []
        if not self.match("PUNC",")"):
            while True:
                ptype = self.parse_type()
                pname = self.pop("IDENT").value
                params.append(Param(ptype, pname))
                if self.match("PUNC",")"):
                    break
                self.pop("PUNC",",")
        body = self.parse_block()
        return FuncDef(return_type=rtype, name=name, params=params, body=body)

    # === Blocks & Statements ===
    def parse_block(self) -> Block:
        self.pop("PUNC","{")
        stmts: List[Stmt] = []
        while not self.match("PUNC","}"):
            stmts.append(self.parse_stmt())
        return Block(stmts)

    def is_type_ahead(self) -> bool:
        tok = self.peek()
        return tok.kind == "KW" and tok.value in ("int","char","bool")

    def parse_stmt(self) -> Stmt:
        tok = self.peek()
        if tok.kind == "KW":
            if tok.value in ("int","char","bool"):
                return self.parse_decl()
            if tok.value == "return":
                self.pop()
                if self.match("PUNC",";"):
                    return Return(None)
                val = self.parse_expr()
                self.pop("PUNC",";")
                return Return(val)
            if tok.value == "if":
                self.pop()
                self.pop("PUNC","(")
                cond = self.parse_expr()
                self.pop("PUNC",")")
                thenb = self.parse_block()
                elseb = None
                if self.match("KW","else"):
                    elseb = self.parse_block()
                return If(cond, thenb, elseb)
            if tok.value == "while":
                self.pop()
                self.pop("PUNC","(")
                cond = self.parse_expr()
                self.pop("PUNC",")")
                body = self.parse_block()
                return While(cond, body)
            if tok.value == "for":
                self.pop()
                self.pop("PUNC","(")
                init: Optional[Union[Decl, ExprStmt]] = None
                if not self.match("PUNC",";"):
                    if self.is_type_ahead():
                        init = self.parse_decl()
                    else:
                        init_expr = self.parse_expr()
                        self.pop("PUNC",";")
                        init = ExprStmt(init_expr)
                cond: Optional[Expr] = None
                if not self.match("PUNC",";"):
                    cond = self.parse_expr()
                    self.pop("PUNC",";")
                update: Optional[Expr] = None
                if not self.match("PUNC",")"):
                    update = self.parse_expr()
                    self.pop("PUNC",")")
                body = self.parse_block()
                return For(init, cond, update, body)
            if tok.value == "switch":
                self.pop()
                self.pop("PUNC","(")
                e = self.parse_expr()
                self.pop("PUNC",")")
                self.pop("PUNC","{")
                cases: List[SwitchCase] = []
                while not self.match("PUNC","}"):
                    label_tok = self.pop()
                    if label_tok.kind == "KW" and label_tok.value == "case":
                        ival = self.pop("INT").value
                        self.pop("PUNC",":")
                        stmts: List[Stmt] = []
                        # read until next case/default or closing brace
                        while True:
                            nxt = self.peek()
                            if (nxt.kind == "KW" and nxt.value in ("case","default")) or (nxt.kind == "PUNC" and nxt.value == "}"):
                                break
                            stmts.append(self.parse_stmt())
                        cases.append(SwitchCase(value=int(ival), statements=stmts))
                    elif label_tok.kind == "KW" and label_tok.value == "default":
                        self.pop("PUNC",":")
                        stmts: List[Stmt] = []
                        while True:
                            nxt = self.peek()
                            if (nxt.kind == "KW" and nxt.value in ("case","default")) or (nxt.kind == "PUNC" and nxt.value == "}"):
                                break
                            stmts.append(self.parse_stmt())
                        cases.append(SwitchCase(value=None, statements=stmts))
                    else:
                        raise SyntaxError(f"Expected 'case' or 'default' at {label_tok.line}:{label_tok.col}")
                return Switch(e, cases)
            if tok.value == "break":
                self.pop(); self.pop("PUNC",";"); return Break()
            if tok.value == "continue":
                self.pop(); self.pop("PUNC",";"); return Continue()
        if tok.kind == "PUNC" and tok.value == "{":
            return self.parse_block()
        # expression statement or empty ';'
        if self.match("PUNC",";"):
            return ExprStmt(None)
        expr = self.parse_expr()
        self.pop("PUNC",";")
        return ExprStmt(expr)

    def parse_decl(self) -> Decl:
        t = self.parse_type()
        items = []
        while True:
            name = self.pop("IDENT").value
            init = None
            if self.match("OP","="):
                init = self.parse_expr()
            items.append(DeclItem(name, init))
            if self.match("PUNC",";"):
                break
            self.pop("PUNC",",")
        return Decl(t, items)

    # === Expressions (Pratt parser) ===
    def parse_expr(self) -> Expr:
        return self.parse_assignment()

    def parse_assignment(self) -> Expr:
        expr = self.parse_binop(0)
        if self.match("OP","="):
            value = self.parse_assignment()
            return Assign(expr, value)
        return expr

    # precedence and associativity
    PRECEDENCE = {
        "||": 1,
        "&&": 2,
        "==": 3, "!=": 3,
        "<": 4, "<=":4, ">":4, ">=":4,
        "+": 5, "-":5,
        "*": 6, "/":6, "%":6,
    }
    RIGHT_ASSOC = set()  # '=' handled in parse_assignment

    def parse_binop(self, min_prec: int) -> Expr:
        left = self.parse_unary()
        while True:
            tok = self.peek()
            if tok.kind == "OP" and tok.value in self.PRECEDENCE and self.PRECEDENCE[tok.value] >= min_prec:
                op = tok.value; self.pop()
                next_min = self.PRECEDENCE[op] + (0 if op in self.RIGHT_ASSOC else 1)
                right = self.parse_binop(next_min)
                left = BinaryOp(op, left, right)
            else:
                break
        return left

    def parse_unary(self) -> Expr:
        tok = self.peek()
        if tok.kind == "OP" and tok.value in ("+","-","!"):
            self.pop()
            return UnaryOp(tok.value, self.parse_unary())
        return self.parse_postfix()

    def parse_postfix(self) -> Expr:
        if self.match("PUNC","("):
            # parenthesized expression
            expr = self.parse_expr()
            self.pop("PUNC",")")
            return expr
        tok = self.peek()
        if tok.kind == "IDENT":
            name = self.pop().value
            # function call?
            if self.match("PUNC","("):
                args = []
                if not self.match("PUNC",")"):
                    while True:
                        args.append(self.parse_expr())
                        if self.match("PUNC",")"):
                            break
                        self.pop("PUNC",",")
                return Call(name, args)
            else:
                return VarRef(name)
        elif tok.kind == "INT":
            self.pop()
            return IntLiteral(int(tok.value))
        elif tok.kind == "KW" and tok.value in ("true","false"):
            self.pop()
            return BoolLiteral(tok.value == "true")
        elif tok.kind == "STRING":
            self.pop()
            # strip quotes, keep escape sequences as-is
            return StringLiteral(tok.value[1:-1])
        elif tok.kind == "CHAR":
            self.pop()
            inner = tok.value[1:-1]
            return CharLiteral(inner)
        raise SyntaxError(f"Unexpected token {tok.kind} {tok.value!r} at {tok.line}:{tok.col}")
