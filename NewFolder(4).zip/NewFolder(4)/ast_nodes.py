
from dataclasses import dataclass, field
from typing import List, Optional, Union

# === Expressions ===
@dataclass
class Expr: ...
@dataclass
class IntLiteral(Expr):
    value: int
@dataclass
class BoolLiteral(Expr):
    value: bool
@dataclass
class CharLiteral(Expr):
    value: str
@dataclass
class StringLiteral(Expr):
    value: str
@dataclass
class VarRef(Expr):
    name: str
@dataclass
class BinaryOp(Expr):
    op: str
    left: Expr
    right: Expr
@dataclass
class UnaryOp(Expr):
    op: str
    expr: Expr
@dataclass
class Assign(Expr):
    target: Expr
    value: Expr
@dataclass
class Call(Expr):
    func: str
    args: List[Expr]

# === Types ===
@dataclass
class TypeSpec:
    name: str  # "int" | "char" | "bool" | "void"

# === Statements ===
@dataclass
class Stmt: ...
@dataclass
class Decl(Stmt):
    type_spec: TypeSpec
    items: List["DeclItem"]  # list of (name, optional init)
@dataclass
class DeclItem:
    name: str
    init: Optional[Expr]
@dataclass
class ExprStmt(Stmt):
    expr: Optional[Expr]  # can be None for empty ';'
@dataclass
class Return(Stmt):
    value: Optional[Expr]
@dataclass
class If(Stmt):
    cond: Expr
    then_branch: "Block"
    else_branch: Optional["Block"]
@dataclass
class While(Stmt):
    cond: Expr
    body: "Block"
@dataclass
class For(Stmt):
    init: Optional[Union[Decl, ExprStmt]]
    cond: Optional[Expr]
    update: Optional[Expr]
    body: "Block"
@dataclass
class Break(Stmt): ...
@dataclass
class Continue(Stmt): ...
@dataclass
class SwitchCase:
    value: Optional[int]  # None means 'default'
    statements: List[Stmt]
@dataclass
class Switch(Stmt):
    expr: Expr
    cases: List[SwitchCase]
@dataclass
class Block(Stmt):
    statements: List[Stmt] = field(default_factory=list)

# === Top-level ===
@dataclass
class Param:
    type_spec: TypeSpec
    name: str
@dataclass
class FuncDef:
    return_type: TypeSpec
    name: str
    params: List[Param]
    body: Block
@dataclass
class Program:
    funcs: List[FuncDef]
