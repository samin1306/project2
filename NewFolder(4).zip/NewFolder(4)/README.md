# Mini-C De-Obfuscator (Step 1)
This is the scaffold + tokenizer + parser + code generator (pretty-printer) for Mini-C.
Run:
```bash
python -m mini_c_deobf.main /mnt/data/mini_c_deobf/examples/obfuscated.mc -o /mnt/data/mini_c_deobf/examples/roundtrip.mc
```
