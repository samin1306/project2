
import re
from typing import List, Tuple, Optional

TOKEN_SPEC = [
    ("WHITESPACE", r"[ \t\r\n]+"),
    ("LINE_COMMENT", r"//[^\n]*"),
    ("BLOCK_COMMENT", r"/\*.*?\*/"),
    ("STRING", r'"([^"\\]|\\.)*"'),
    ("CHAR", r"'([^'\\]|\\.)'"),
    ("INT", r"\d+"),
    # multi-char operators first
    ("OP", r"==|!=|<=|>=|\+\+|--|\+=|-=|\*=|/=|%=|&&|\|\|"),
    ("OP", r"[+\-*/%<>=!&|]"),
    ("PUNC", r"[(){},;:]"),
    ("IDENT", r"[A-Za-z_]\w*"),
]

KEYWORDS = {
    "int","char","bool","void",
    "if","else","while","for","return",
    "switch","case","default","break","continue",
    "true","false",
}

class Token:
    def __init__(self, kind: str, value: str, pos: int, line: int, col: int):
        self.kind = kind
        self.value = value
        self.pos = pos
        self.line = line
        self.col = col
    def __repr__(self):
        return f"Token({self.kind},{self.value!r},@{self.line}:{self.col})"

def tokenize(src: str) -> List[Token]:
    pattern = "|".join(f"(?P<T{i}>{pat})" for i,(_,pat) in enumerate(TOKEN_SPEC))
    # compile with DOTALL for block comments
    regex = re.compile(pattern, re.DOTALL)
    i = 0
    line = 1
    col = 1
    tokens: List[Token] = []
    while i < len(src):
        m = regex.match(src, i)
        if not m:
            snippet = src[i:i+20].replace("\n","\\n")
            raise SyntaxError(f"Unexpected character at {line}:{col}: {snippet}")
        kind_idx = [k for k,v in m.groupdict().items() if v is not None][0]
        idx = int(kind_idx[1:])
        kind, pat = TOKEN_SPEC[idx]
        text = m.group(kind_idx)
        if kind in ("WHITESPACE","LINE_COMMENT","BLOCK_COMMENT"):
            pass
        elif kind == "IDENT":
            if text in KEYWORDS:
                tokens.append(Token("KW", text, i, line, col))
            else:
                tokens.append(Token("IDENT", text, i, line, col))
        else:
            tokens.append(Token(kind, text, i, line, col))
        # update position
        newlines = text.count("\n")
        if newlines:
            line += newlines
            col = len(text.split("\n")[-1]) + 1
        else:
            col += len(text)
        i = m.end()
    tokens.append(Token("EOF","", i, line, col))
    return tokens
