
import argparse, sys, pathlib
from parser import Parser
from codegen import CodeGen
from transforms.basic import apply_basic_transforms

def run(input_path: str, output_path: str):
    src = pathlib.Path(input_path).read_text(encoding="utf-8")
    parser = Parser(src)
    prog = parser.parse_program()
    prog = apply_basic_transforms(prog)
    code = CodeGen().gen_program(prog)
    pathlib.Path(output_path).write_text(code, encoding="utf-8")
    return code

def main():
    ap = argparse.ArgumentParser(description="Mini-C De-Obfuscator (Step 1: parser & pretty-printer)")
    ap.add_argument("input", help="path to obfuscated.mc (Mini-C)")
    ap.add_argument("-o","--output", default="cleaned.mc", help="output file")
    args = ap.parse_args()
    run(args.input, args.output)

if __name__ == "__main__":
    main()
