
from ast_nodes import *
from typing import List, Optional, Union

class CodeGen:
    def __init__(self):
        self.indent = 0
        self.lines: List[str] = []

    def emit(self, s=""):
        self.lines.append("    "*self.indent + s)

    def gen_program(self, prog: Program) -> str:
        self.lines = []
        for i,f in enumerate(prog.funcs):
            if i>0: self.emit()
            self.gen_func(f)
        return "\n".join(self.lines)

    def gen_type(self, t: TypeSpec) -> str:
        return t.name

    def gen_params(self, params: List[Param]) -> str:
        return ", ".join(f"{self.gen_type(p.type_spec)} {p.name}" for p in params)

    def gen_block(self, b: Block):
        self.emit("{")
        self.indent += 1
        for stmt in b.statements:
            self.gen_stmt(stmt)
        self.indent -= 1
        self.emit("}")

    def gen_stmt(self, s: Stmt):
        if isinstance(s, Decl):
            parts = []
            for it in s.items:
                if it.init is None:
                    parts.append(it.name)
                else:
                    parts.append(f"{it.name} = {self.gen_expr(it.init)}")
            self.emit(f"{self.gen_type(s.type_spec)} " + ", ".join(parts) + ";")
        elif isinstance(s, ExprStmt):
            if s.expr is None:
                self.emit(";")
            else:
                self.emit(self.gen_expr(s.expr) + ";")
        elif isinstance(s, Return):
            if s.value is None:
                self.emit("return;")
            else:
                self.emit("return " + self.gen_expr(s.value) + ";")
        elif isinstance(s, If):
            self.emit(f"if ({self.gen_expr(s.cond)})")
            self.gen_block(s.then_branch)
            if s.else_branch is not None:
                self.emit("else")
                self.gen_block(s.else_branch)
        elif isinstance(s, While):
            self.emit(f"while ({self.gen_expr(s.cond)})")
            self.gen_block(s.body)
        elif isinstance(s, For):
            self.emit("for (",)
            # Build header
            init_str = ""
            if s.init is None:
                init_str = ";"
            elif isinstance(s.init, Decl):
                # Only simple single item decl supported inline
                items = []
                for it in s.init.items:
                    if it.init is None:
                        items.append(it.name)
                    else:
                        items.append(f"{it.name} = {self.gen_expr(it.init)}")
                init_str = f"{self.gen_type(s.init.type_spec)} " + ", ".join(items) + ";"
            elif isinstance(s.init, ExprStmt):
                init_str = self.gen_expr(s.init.expr) + ";"
            cond_str = "" if s.cond is None else self.gen_expr(s.cond)
            upd_str = "" if s.update is None else self.gen_expr(s.update)
            self.lines[-1] += init_str + " " + cond_str + "; " + upd_str + ")"
            self.gen_block(s.body)
        elif isinstance(s, Break):
            self.emit("break;")
        elif isinstance(s, Continue):
            self.emit("continue;")
        elif isinstance(s, Switch):
            self.emit(f"switch ({self.gen_expr(s.expr)}) {{")
            self.indent += 1
            for c in s.cases:
                if c.value is None:
                    self.emit("default:")
                else:
                    self.emit(f"case {c.value}:")
                self.indent += 1
                for st in c.statements:
                    self.gen_stmt(st)
                self.indent -= 1
            self.indent -= 1
            self.emit("}")
        elif isinstance(s, Block):
            self.gen_block(s)
        else:
            raise NotImplementedError(type(s))

    def gen_expr(self, e: Expr) -> str:
        if isinstance(e, IntLiteral):
            return str(e.value)
        if isinstance(e, BoolLiteral):
            return "true" if e.value else "false"
        if isinstance(e, CharLiteral):
            return "'" + e.value + "'"
        if isinstance(e, StringLiteral):
            # keep as quoted
            return '"' + e.value + '"'
        if isinstance(e, VarRef):
            return e.name
        if isinstance(e, BinaryOp):
            return f"({self.gen_expr(e.left)} {e.op} {self.gen_expr(e.right)})"
        if isinstance(e, UnaryOp):
            return f"({e.op}{self.gen_expr(e.expr)})"
        if isinstance(e, Assign):
            return f"({self.gen_expr(e.target)} = {self.gen_expr(e.value)})"
        if isinstance(e, Call):
            return f"{e.func}(" + ", ".join(self.gen_expr(a) for a in e.args) + ")"
        raise NotImplementedError(type(e))

    def gen_func(self, f: FuncDef):
        self.emit(f"{self.gen_type(f.return_type)} {f.name}(" + self.gen_params(f.params) + ")")
        self.gen_block(f.body)
