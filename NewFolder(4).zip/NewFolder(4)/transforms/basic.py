
from ast_nodes import *

class ExprSimplifier:
    """Simplify constant expressions and trivial rewrites."""
    def visit(self, e: Expr) -> Expr:
        if isinstance(e, BinaryOp):
            left = self.visit(e.left)
            right = self.visit(e.right)
            # simplify known pattern: x - (-y) => x + y
            if e.op == "-" and isinstance(right, UnaryOp) and right.op == "-":
                return BinaryOp("+", left, self.visit(right.expr))
            # constant folding
            if isinstance(left, IntLiteral) and isinstance(right, IntLiteral):
                try:
                    if e.op == "+": return IntLiteral(left.value + right.value)
                    if e.op == "-": return IntLiteral(left.value - right.value)
                    if e.op == "*": return IntLiteral(left.value * right.value)
                    if e.op == "/": return IntLiteral(left.value // right.value)
                    if e.op == "%": return IntLiteral(left.value % right.value)
                except Exception:
                    pass
            return BinaryOp(e.op, left, right)
        if isinstance(e, UnaryOp):
            inner = self.visit(e.expr)
            # simplify --x => x
            if e.op == "-" and isinstance(inner, UnaryOp) and inner.op == "-":
                return self.visit(inner.expr)
            if e.op == "+" and isinstance(inner, IntLiteral):
                return inner
            return UnaryOp(e.op, inner)
        if isinstance(e, Assign):
            return Assign(self.visit(e.target), self.visit(e.value))
        if isinstance(e, Call):
            return Call(e.func, [self.visit(a) for a in e.args])
        return e

class DeadCodeRemover:
    """Remove unused variable declarations (basic)."""
    def collect_used_vars(self, prog: Program) -> set[str]:
        used = set()
        def visit_expr(e: Expr):
            if isinstance(e, VarRef):
                used.add(e.name)
            elif isinstance(e, BinaryOp):
                visit_expr(e.left); visit_expr(e.right)
            elif isinstance(e, Assign):
                visit_expr(e.target); visit_expr(e.value)
            elif isinstance(e, UnaryOp):
                visit_expr(e.expr)
            elif isinstance(e, Call):
                for a in e.args: visit_expr(a)
        def visit_stmt(s: Stmt):
            if isinstance(s, Decl):
                for it in s.items:
                    if it.init: visit_expr(it.init)
            elif isinstance(s, ExprStmt) and s.expr: visit_expr(s.expr)
            elif isinstance(s, Return) and s.value: visit_expr(s.value)
            elif isinstance(s, If):
                visit_expr(s.cond); visit_block(s.then_branch)
                if s.else_branch: visit_block(s.else_branch)
            elif isinstance(s, While):
                visit_expr(s.cond); visit_block(s.body)
            elif isinstance(s, For):
                if isinstance(s.init, Decl):
                    for it in s.init.items:
                        if it.init: visit_expr(it.init)
                elif isinstance(s.init, ExprStmt) and s.init.expr:
                    visit_expr(s.init.expr)
                if s.cond: visit_expr(s.cond)
                if s.update: visit_expr(s.update)
                visit_block(s.body)
            elif isinstance(s, Switch):
                visit_expr(s.expr)
                for c in s.cases:
                    for st in c.statements: visit_stmt(st)
            elif isinstance(s, Block):
                visit_block(s)
        def visit_block(b: Block):
            for st in b.statements: visit_stmt(st)
        for f in prog.funcs:
            visit_block(f.body)
        return used

    def transform(self, prog: Program) -> Program:
        used = self.collect_used_vars(prog)
        def filter_block(b: Block):
            new_stmts = []
            for st in b.statements:
                if isinstance(st, Decl):
                    new_items = [it for it in st.items if it.name in used or (it.init is not None)]
                    if new_items:
                        new_stmts.append(Decl(st.type_spec, new_items))
                elif isinstance(st, Block):
                    filter_block(st)
                    new_stmts.append(st)
                else:
                    new_stmts.append(st)
            b.statements = new_stmts
        for f in prog.funcs:
            filter_block(f.body)
        return prog

def apply_basic_transforms(prog: Program) -> Program:
    simp = ExprSimplifier()
    def visit_expr(e):
        return simp.visit(e)
    def visit_stmt(s):
        if isinstance(s, Decl):
            for it in s.items:
                if it.init: it.init = visit_expr(it.init)
        elif isinstance(s, ExprStmt) and s.expr:
            s.expr = visit_expr(s.expr)
        elif isinstance(s, Return) and s.value:
            s.value = visit_expr(s.value)
        elif isinstance(s, If):
            s.cond = visit_expr(s.cond)
            visit_block(s.then_branch)
            if s.else_branch: visit_block(s.else_branch)
        elif isinstance(s, While):
            s.cond = visit_expr(s.cond)
            visit_block(s.body)
        elif isinstance(s, For):
            if isinstance(s.init, Decl):
                for it in s.init.items:
                    if it.init: it.init = visit_expr(it.init)
            elif isinstance(s.init, ExprStmt) and s.init.expr:
                s.init.expr = visit_expr(s.init.expr)
            if s.cond: s.cond = visit_expr(s.cond)
            if s.update: s.update = visit_expr(s.update)
            visit_block(s.body)
        elif isinstance(s, Switch):
            s.expr = visit_expr(s.expr)
            for c in s.cases:
                for st in c.statements: visit_stmt(st)
        elif isinstance(s, Block):
            visit_block(s)
    def visit_block(b: Block):
        for st in b.statements:
            visit_stmt(st)
    for f in prog.funcs:
        visit_block(f.body)
    dcr = DeadCodeRemover()
    return dcr.transform(prog)
